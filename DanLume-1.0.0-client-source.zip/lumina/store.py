"""SQLite 持久层：日程、邮件、联系人、设置。"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from . import secure
from .config import DB_PATH


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _to_dt(date_str: str, time_str: str) -> datetime:
    return datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")


def _clock5(text: str) -> str:
    """'9:40' → '09:40'（老数据里可能存着单位数小时）"""
    raw = str(text or "").strip()[:5]
    if not raw:
        return "09:00"
    if ":" not in raw:
        return "09:00"
    hour, minute = raw.split(":", 1)
    if not hour.isdigit() or not minute.isdigit():
        return "09:00"
    return f"{int(hour):02d}:{int(minute):02d}"


def _parse_dt(text) -> Optional[datetime]:
    """把 setting / 列里的时间文本解析成 datetime，认不出来就是 None。"""
    raw = str(text or "").strip()
    if not raw:
        return None
    for pattern in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw, pattern)
        except ValueError:
            continue
    return None


def compute_remind_at(date_str: str, start_time: str, minutes: Optional[int]) -> Optional[str]:
    if minutes is None:
        return None
    dt = _to_dt(date_str, start_time) - timedelta(minutes=int(minutes))
    return dt.strftime("%Y-%m-%d %H:%M:%S")


REPEAT_KINDS = ("", "daily", "weekly", "monthly", "yearly")


def normalize_repeat(value) -> str:
    """把界面/导入来的重复规则规整成 ''/daily/weekly/monthly/yearly。"""
    text = str(value or "").strip().lower()
    aliases = {
        "": "", "none": "", "never": "", "不重复": "", "0": "",
        "day": "daily", "daily": "daily", "每天": "daily", "每日": "daily",
        "week": "weekly", "weekly": "weekly", "每周": "weekly", "每星期": "weekly",
        "month": "monthly", "monthly": "monthly", "每月": "monthly",
        "year": "yearly", "yearly": "yearly", "每年": "yearly",
    }
    if text in aliases:
        return aliases[text]
    return "" if text not in REPEAT_KINDS else text


def _add_months(year: int, month: int, day: int) -> Optional[str]:
    """下个月的同一个「几号」；那个月没有这一天（比如 31 号）就返回 None。"""
    month += 1
    if month > 12:
        month = 1
        year += 1
    try:
        return datetime(year, month, day).strftime("%Y-%m-%d")
    except ValueError:
        return None


def recurrence_days(start_date: str, repeat: str, start: str, end: str,
                    limit: int = 400) -> List[str]:
    """把「从哪一天开始、按什么规则重复」展开成 [start, end] 区间里的日期。

    * daily：每天；weekly：每 7 天（同一个星期几）；
    * monthly：每月同一个「几号」，没有那一天的月份跳过（1/31 → 3/31、5/31…）；
    * yearly：每年同月同日，2/29 只在闰年出现。
    """
    repeat = normalize_repeat(repeat)
    if not repeat:
        return []
    try:
        begin = datetime.strptime(str(start_date)[:10], "%Y-%m-%d")
        low = datetime.strptime(str(start)[:10], "%Y-%m-%d")
        high = datetime.strptime(str(end)[:10], "%Y-%m-%d")
    except ValueError:
        return []
    if high < begin:
        return []
    days: List[str] = []
    if repeat == "daily":
        cursor = max(begin, low)
        while cursor <= high and len(days) < limit:
            days.append(cursor.strftime("%Y-%m-%d"))
            cursor += timedelta(days=1)
        return days
    if repeat == "weekly":
        cursor = begin
        if cursor < low:
            cursor += timedelta(days=7 * ((low - cursor).days // 7))
            while cursor < low:
                cursor += timedelta(days=7)
        while cursor <= high and len(days) < limit:
            days.append(cursor.strftime("%Y-%m-%d"))
            cursor += timedelta(days=7)
        return days
    if repeat == "monthly":
        year, month = begin.year, begin.month
        while (year, month) <= (high.year, high.month) and len(days) < limit:
            try:
                occurrence = datetime(year, month, begin.day)
            except ValueError:
                occurrence = None
            if occurrence is not None and occurrence >= begin \
                    and low <= occurrence <= high:
                days.append(occurrence.strftime("%Y-%m-%d"))
            month += 1
            if month > 12:
                month, year = 1, year + 1
        return days
    # yearly
    for year in range(begin.year, high.year + 1):
        try:
            occurrence = datetime(year, begin.month, begin.day)
        except ValueError:
            continue          # 2/29 在平年跳过
        if occurrence >= begin and low <= occurrence <= high:
            days.append(occurrence.strftime("%Y-%m-%d"))
        if len(days) >= limit:
            break
    return days


class Store:
    """所有界面共享的数据库访问对象（单连接，主线程使用）。"""

    def __init__(self, path: Path | str = DB_PATH):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path), timeout=10.0, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        try:
            # 别让一次卡住的写把界面拖住 10 秒
            self.conn.execute("PRAGMA busy_timeout=2500")
        except Exception:
            pass
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self._create_schema()
        self._apply_defaults()
        self.seed_demo_data()

    # ------------------------------------------------------------------ 基础
    def _create_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                date TEXT NOT NULL,
                start_time TEXT NOT NULL DEFAULT '09:00',
                end_time TEXT NOT NULL DEFAULT '10:00',
                remind_minutes INTEGER,
                remind_at TEXT,
                notified INTEGER NOT NULL DEFAULT 0,
                done INTEGER NOT NULL DEFAULT 0,
                color TEXT NOT NULL DEFAULT 'violet',
                repeat TEXT NOT NULL DEFAULT '',
                repeat_skip TEXT NOT NULL DEFAULT '',
                repeat_until TEXT NOT NULL DEFAULT '',
                done_dates TEXT NOT NULL DEFAULT '',
                notified_dates TEXT NOT NULL DEFAULT '',
                snooze_until TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_events_date ON events(date);

            CREATE TABLE IF NOT EXISTS mails (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                to_addr TEXT NOT NULL DEFAULT '',
                subject TEXT NOT NULL DEFAULT '',
                html TEXT NOT NULL DEFAULT '',
                text TEXT NOT NULL DEFAULT '',
                tasks_json TEXT NOT NULL DEFAULT '[]',
                attachments_json TEXT NOT NULL DEFAULT '[]',
                note TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'draft',
                error TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                sent_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_mails_status ON mails(status);

            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL DEFAULT '',
                email TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS memos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL DEFAULT '',
    html TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_memos_updated ON memos(updated_at);
CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    fetched_at TEXT NOT NULL,
    published_at TEXT NOT NULL DEFAULT '',
    read_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_notices_url ON notices(url);
CREATE TABLE IF NOT EXISTS server_announcements (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL DEFAULT '',
    body TEXT NOT NULL DEFAULT '',
    level TEXT NOT NULL DEFAULT 'info',
    pinned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT '',
    expires_at TEXT NOT NULL DEFAULT '',
    received_at TEXT NOT NULL,
    read_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_server_ann_received
    ON server_announcements(received_at);
CREATE TABLE IF NOT EXISTS event_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                color TEXT NOT NULL DEFAULT 'teal',
                created_at TEXT NOT NULL
            );

CREATE TABLE IF NOT EXISTS important_dates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                date TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                color TEXT NOT NULL DEFAULT 'rose',
                kind TEXT NOT NULL DEFAULT 'custom',
                event_id INTEGER,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL DEFAULT ''
            );
            """
        )
        self.conn.commit()
        self._migrate()

    def _migrate(self) -> None:
        """老库补列：events.group_id（日程所属分组）、events.repeat（重复规则）、
        notices.published_at（网页上的发布时间）。"""
        columns = {row["name"] for row in self.conn.execute("PRAGMA table_info(events)")}
        if "group_id" not in columns:
            self.conn.execute("ALTER TABLE events ADD COLUMN group_id INTEGER")
            self.conn.commit()
        if "repeat" not in columns:
            # 重复规则：'' 不重复 / daily / weekly / monthly / yearly
            self.conn.execute(
                "ALTER TABLE events ADD COLUMN repeat TEXT NOT NULL DEFAULT ''")
            self.conn.commit()
        if "repeat_skip" not in columns:
            # 跳过的那几次（逗号分隔的日期），用于「删除本次」
            self.conn.execute(
                "ALTER TABLE events ADD COLUMN repeat_skip TEXT NOT NULL DEFAULT ''")
            self.conn.commit()
        if "repeat_until" not in columns:
            # 重复到哪一天为止（空 = 一直重复），用于「删除后续」
            self.conn.execute(
                "ALTER TABLE events ADD COLUMN repeat_until TEXT NOT NULL DEFAULT ''")
            self.conn.commit()
        if "done_dates" not in columns:
            # 重复日程里**已经完成的那几次**（逗号分隔日期）。
            # 以前「标记完成」写的是母事件的 done，于是整条重复系列（含以后每一次）
            # 都变成已完成——用户反馈的问题。旧数据在下面顺手修一次。
            self.conn.execute(
                "ALTER TABLE events ADD COLUMN done_dates TEXT NOT NULL DEFAULT ''")
            self.conn.commit()
        if "notified_dates" not in columns:
            # 重复日程里**已经提醒过的那几次**，按天记；一次提醒不会把以后都吃掉
            self.conn.execute(
                "ALTER TABLE events ADD COLUMN notified_dates TEXT NOT NULL DEFAULT ''")
            self.conn.commit()
        if "snooze_until" not in columns:
            # 「稍后 10 分钟」推迟到什么时候（只对重复日程的那一天有效）
            self.conn.execute(
                "ALTER TABLE events ADD COLUMN snooze_until TEXT NOT NULL DEFAULT ''")
            self.conn.commit()
        try:
            # 历史数据修复（幂等）：把「整条系列被标成完成」还原成「只有那一天完成」
            self.conn.execute(
                "UPDATE events SET done_dates = substr(date, 1, 10), done = 0 "
                "WHERE repeat IS NOT NULL AND repeat != '' AND done = 1 "
                "AND (done_dates IS NULL OR done_dates = '')")
            self.conn.commit()
        except Exception:
            pass
        notice_columns = {
            row["name"] for row in self.conn.execute("PRAGMA table_info(notices)")}
        if notice_columns and "published_at" not in notice_columns:
            self.conn.execute(
                "ALTER TABLE notices ADD COLUMN published_at TEXT NOT NULL DEFAULT ''")
            self.conn.commit()

    def _apply_defaults(self) -> None:
        defaults = {
            "smtp_host": "",
            "smtp_port": "",
            "smtp_security": "ssl",
            "smtp_user": "",
            "smtp_password": "",
            "sender_name": "",
            "sender_email": "",
            "default_to": "",
            "reminders_enabled": "1",
            "reminder_sound": "1",
            "timetable_enabled": "0",
            "timetable_status": "",
            "theme_accent": "#2F7A5F",
            "theme_accent2": "#D99A4E",
            "theme_bg": "linen",
            "theme_alpha": "0.98",
            "theme_glass": "1",
            "theme_blur": "24",
            "seeded": "0",
        }
        for key, value in defaults.items():
            self.conn.execute(
                "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (key, value)
            )
        self.conn.commit()

    def seed_demo_data(self) -> None:
        """仅在首次启动时写入几条示例数据，方便直接体验。"""
        if self.get_setting("seeded") == "1":
            return
        today = datetime.now().date()
        samples = [
            (today, "09:30", "10:30", "项目周会", "同步本周里程碑进度，确认交付物与风险项。", 15, "violet", 0),
            (today, "14:00", "15:30", "完成季度汇报材料", "整理数据看板与关键结论，输出汇报初稿。", 30, "teal", 0),
            (today, "18:30", "19:30", "健身训练", "力量训练 45 分钟 + 拉伸。", 15, "amber", 0),
            (today + timedelta(days=1), "10:00", "11:00", "设计评审会", "评审新版工作台交互方案，收集反馈。", 30, "sky", 0),
            (today - timedelta(days=1), "16:00", "17:30", "整理客户反馈并输出改进清单", "汇总 12 条反馈，输出优先级与负责人建议。", None, "rose", 1),
        ]
        for day, start, end, title, desc, remind, color, done in samples:
            d = day.strftime("%Y-%m-%d")
            self.add_event(
                title=title,
                description=desc,
                date=d,
                start_time=start,
                end_time=end,
                remind_minutes=remind,
                color=color,
                done=bool(done),
            )
        if not self.list_contacts():
            self.add_contact("王经理（示例）", "wang.manager@example.com")
        self.set_setting("seeded", "1")

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    # ------------------------------------------------------------------ 设置
    # ---------------------------------------------------------- 备忘录
    def list_memos(self) -> List[Dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM memos ORDER BY updated_at DESC, id DESC"
        ).fetchall()
        return [dict(row) for row in rows]

    def get_memo(self, memo_id: int) -> Optional[Dict[str, Any]]:
        row = self.conn.execute(
            "SELECT * FROM memos WHERE id = ?", (int(memo_id),)
        ).fetchone()
        return dict(row) if row else None

    def add_memo(self, title: str = "", html: str = "") -> int:
        ts = now_str()
        cursor = self.conn.execute(
            "INSERT INTO memos(title, html, created_at, updated_at) VALUES (?,?,?,?)",
            (title, html, ts, ts),
        )
        self.conn.commit()
        return int(cursor.lastrowid)

    def update_memo(self, memo_id: int, title: Optional[str] = None,
                    html: Optional[str] = None) -> None:
        fields: List[str] = ["updated_at = ?"]
        params: List[Any] = [now_str()]
        if title is not None:
            fields.append("title = ?")
            params.append(title)
        if html is not None:
            fields.append("html = ?")
            params.append(html)
        params.append(int(memo_id))
        self.conn.execute(
            "UPDATE memos SET " + ", ".join(fields) + " WHERE id = ?", params
        )
        self.conn.commit()

    def delete_memo(self, memo_id: int) -> None:
        self.conn.execute("DELETE FROM memos WHERE id = ?", (int(memo_id),))
        self.conn.commit()

    # ---------------------------------------------------------- 通知
    def add_notice(self, source: str, title: str, url: str,
                   published_at: str = "") -> bool:
        """插入一条通知；已存在（按 URL 去重）返回 False。"""
        existing = self.conn.execute(
            "SELECT id, published_at FROM notices WHERE url = ?", (url,)
        ).fetchone()
        if existing:
            # 老数据没有发布时间：这次抓到了就补上
            if published_at and not (existing["published_at"] or "").strip():
                self.conn.execute(
                    "UPDATE notices SET published_at = ? WHERE url = ?",
                    (published_at, url))
                self.conn.commit()
            return False
        self.conn.execute(
            "INSERT INTO notices(source, title, url, fetched_at, published_at)"
            " VALUES (?,?,?,?,?)",
            (source, title, url, now_str(), published_at or ""),
        )
        self.conn.commit()
        return True

    def list_notices(self, limit: int = 40) -> List[Dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM notices ORDER BY id DESC LIMIT ?", (int(limit),)
        ).fetchall()
        return [dict(row) for row in rows]

    def unread_notice_count(self) -> int:
        row = self.conn.execute(
            "SELECT COUNT(*) AS n FROM notices WHERE read_at IS NULL"
        ).fetchone()
        return int(row["n"]) if row else 0

    def mark_notices_read(self) -> None:
        self.conn.execute(
            "UPDATE notices SET read_at = ? WHERE read_at IS NULL", (now_str(),)
        )
        self.conn.commit()

    # ---------------------------------------------------------- 服务器公告
    # 服务器（自家账号服务器）推下来的公告单独一张表：id 就是服务器上的公告 id，
    # 用它去重、也用来记「已经收到哪儿了」（settings.last_announcement_id）。
    def add_server_announcement(self, item: Dict[str, Any]) -> bool:
        """存一条服务器公告；这条之前没有（= 新公告）返回 True。"""
        if not isinstance(item, dict):
            return False
        try:
            ann_id = int(item.get("id") or 0)
        except (TypeError, ValueError):
            return False
        if ann_id <= 0:
            return False
        title = str(item.get("title") or "").strip()
        body = str(item.get("body") or "")
        level = str(item.get("level") or "info").strip().lower() or "info"
        if level not in ("info", "warning", "critical"):
            level = "info"
        pinned = 1 if item.get("pinned") else 0
        created_at = str(item.get("created_at") or "")
        expires_at = str(item.get("expires_at") or "")
        existing = self.conn.execute(
            "SELECT id FROM server_announcements WHERE id = ?", (ann_id,)).fetchone()
        if existing:
            # 服务器上可能改过内容：更新文字，但保留本地的已读状态
            self.conn.execute(
                "UPDATE server_announcements SET title = ?, body = ?, level = ?,"
                " pinned = ?, created_at = ?, expires_at = ? WHERE id = ?",
                (title, body, level, pinned, created_at, expires_at, ann_id))
            self.conn.commit()
            return False
        self.conn.execute(
            "INSERT INTO server_announcements(id, title, body, level, pinned,"
            " created_at, expires_at, received_at) VALUES (?,?,?,?,?,?,?,?)",
            (ann_id, title, body, level, pinned, created_at, expires_at, now_str()))
        self.conn.commit()
        return True

    def list_server_announcements(self, limit: int = 100) -> List[Dict[str, Any]]:
        """服务器公告：置顶的在前，然后按服务器 id 从新到旧。"""
        rows = self.conn.execute(
            "SELECT * FROM server_announcements"
            " ORDER BY pinned DESC, id DESC LIMIT ?", (int(limit),)).fetchall()
        items = []
        for row in rows:
            item = dict(row)
            item["pinned"] = bool(item.get("pinned"))
            items.append(item)
        return items

    def unread_server_announcement_count(self) -> int:
        row = self.conn.execute(
            "SELECT COUNT(*) AS n FROM server_announcements WHERE read_at IS NULL"
        ).fetchone()
        return int(row["n"]) if row else 0

    def mark_server_announcements_read(self) -> None:
        self.conn.execute(
            "UPDATE server_announcements SET read_at = ? WHERE read_at IS NULL",
            (now_str(),))
        self.conn.commit()

    def mark_server_announcement_read(self, ann_id: int) -> None:
        self.conn.execute(
            "UPDATE server_announcements SET read_at = ? WHERE id = ? AND read_at IS NULL",
            (now_str(), int(ann_id)))
        self.conn.commit()

    def get_setting(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value: Any) -> None:
        self.conn.execute(
            "INSERT INTO settings(key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, "" if value is None else str(value)),
        )
        self.conn.commit()

    def update_settings(self, values: Dict[str, Any]) -> None:
        with self.conn:
            for key, value in values.items():
                self.conn.execute(
                    "INSERT INTO settings(key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                    (key, "" if value is None else str(value)),
                )

    def get_secret(self, key: str, default: str = "") -> str:
        stored = self.get_setting(key, "")
        if not stored:
            return default
        return secure.unprotect(stored)

    def set_secret(self, key: str, plain: str) -> None:
        self.set_setting(key, secure.protect(plain) if plain else "")

    # ------------------------------------------------------------------ 日程
    @staticmethod
    def _event_row(row: sqlite3.Row) -> Dict[str, Any]:
        item = dict(row)
        item["done"] = bool(item["done"])
        item["notified"] = bool(item["notified"])
        return item

    def add_event(
        self,
        title: str,
        description: str = "",
        date: str = "",
        start_time: str = "09:00",
        end_time: str = "10:00",
        remind_minutes: Optional[int] = None,
        color: str = "violet",
        done: bool = False,
        group_id=None,
        repeat: str = "",
    ) -> int:
        ts = now_str()
        repeat = normalize_repeat(repeat)
        remind_at = compute_remind_at(date, start_time, remind_minutes)
        cur = self.conn.execute(
            "INSERT INTO events(title, description, date, start_time, end_time, remind_minutes,"
            " remind_at, notified, done, color, group_id, repeat, created_at, updated_at)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                title.strip(), description, date, start_time, end_time, remind_minutes,
                remind_at, 0, 1 if done else 0, color, group_id, repeat, ts, ts,
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def update_event(self, event_id: int, **fields: Any) -> None:
        allowed = {
            "title", "description", "date", "start_time", "end_time",
            "remind_minutes", "color", "done", "group_id", "repeat",
        }
        if "repeat" in fields:
            fields["repeat"] = normalize_repeat(fields["repeat"])
        fields = {k: v for k, v in fields.items() if k in allowed}
        if not fields:
            return
        row = self.get_event(event_id)
        if row is None:
            return
        if "done" in fields and normalize_repeat(row.get("repeat") or ""):
            # 重复日程的完成状态按「哪一天」记，不写母行（母行一写，整串都变已完成）
            day = str(fields.get("date") or row.get("date") or "")[:10]
            self.set_done(int(event_id), bool(fields.pop("done")), day)
            if not fields:
                return
        merged = {**row, **fields}
        remind_at = compute_remind_at(
            merged["date"], merged["start_time"], merged["remind_minutes"]
        )
        # 时间被修改后重新启用提醒
        time_changed = (
            merged["date"] != row["date"]
            or merged["start_time"] != row["start_time"]
            or merged["remind_minutes"] != row["remind_minutes"]
        )
        sets = [f"{key} = ?" for key in fields]
        params: List[Any] = [int(v) if isinstance(v, bool) else v for v in fields.values()]
        sets += ["remind_at = ?", "updated_at = ?"]
        params += [remind_at, now_str()]
        if time_changed:
            sets.append("notified = ?")
            params.append(0)
        params.append(event_id)
        self.conn.execute(f"UPDATE events SET {', '.join(sets)} WHERE id = ?", params)
        self.conn.commit()

    def get_event(self, event_id: int) -> Optional[Dict[str, Any]]:
        row = self.conn.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
        return self._event_row(row) if row else None

    def skip_occurrence(self, event_id: int, day: str) -> None:
        """「删除本次」：把这一天记进 repeat_skip，其余照常重复。"""
        row = self.get_event(event_id)
        if row is None:
            return
        day = str(day or "")[:10]
        if not day:
            return
        skips = [part.strip() for part in str(row.get("repeat_skip") or "").split(",")
                 if part.strip()]
        if day not in skips:
            skips.append(day)
        self.conn.execute("UPDATE events SET repeat_skip = ?, updated_at = ?"
                          " WHERE id = ?", (",".join(sorted(skips)), now_str(),
                                            int(event_id)))
        self.conn.commit()

    def end_repeat_before(self, event_id: int, day: str) -> None:
        """「删除后续」：让重复在这一天之前就结束（这一天及以后都不再出现）。"""
        row = self.get_event(event_id)
        if row is None:
            return
        day = str(day or "")[:10]
        first = str(row.get("date") or "")[:10]
        if not day or day <= first:
            self.delete_event(int(event_id))     # 从第一次就不想要了 = 全删
            return
        try:
            until = (datetime.strptime(day, "%Y-%m-%d")
                     - timedelta(days=1)).strftime("%Y-%m-%d")
        except ValueError:
            until = day
        self.conn.execute("UPDATE events SET repeat_until = ?, updated_at = ?"
                          " WHERE id = ?", (until, now_str(), int(event_id)))
        self.conn.commit()

    def delete_event(self, event_id: int) -> None:
        self.conn.execute("DELETE FROM events WHERE id = ?", (event_id,))
        self.conn.commit()

    def auto_complete_past(self, now: Optional[datetime] = None) -> int:
        """把「已经过了结束时间」的日程自动标为已完成，返回更新条数。

        重复日程（repeat 非空）**不能**走这条路：母事件代表整串，把它标成已完成会让
        以后每一次都显示为已完成（用户反馈的第二个问题）。它们的每一次改由
        `_auto_complete_occurrences` 记进 done_dates。
        """
        now = now or datetime.now()
        today = now.strftime("%Y-%m-%d")
        hhmm = now.strftime("%H:%M")
        changed = 0
        try:
            cursor = self.conn.execute(
                "UPDATE events SET done = 1, updated_at = ? "
                "WHERE done = 0 AND (repeat IS NULL OR repeat = '') AND ("
                "  date < ? OR (date = ? AND "
                "  COALESCE(NULLIF(end_time, ''), '23:59') <= ?))",
                (now_str(), today, today, hhmm),
            )
            self.conn.commit()
            changed = int(cursor.rowcount or 0)
        except Exception:
            pass
        try:
            changed += self._auto_complete_occurrences(today)
        except Exception:
            pass
        return changed

    def _auto_complete_occurrences(self, today: str) -> int:
        """重复日程里已经过去的那些天记进 done_dates；今天这次还在进行，不替用户勾。"""
        try:
            yesterday = (datetime.strptime(today, "%Y-%m-%d")
                         - timedelta(days=1)).strftime("%Y-%m-%d")
        except ValueError:
            return 0
        rows = self.conn.execute(
            "SELECT * FROM events WHERE repeat IS NOT NULL AND repeat != ''"
            " AND date < ?", (today,)).fetchall()
        touched = 0
        for row in rows:
            master = self._event_row(row)
            skip = {part.strip() for part in str(master.get("repeat_skip") or "").split(",")
                    if part.strip()}
            marked = {part.strip() for part in str(master.get("done_dates") or "").split(",")
                      if part.strip()}
            days = recurrence_days(master.get("date") or "", master.get("repeat") or "",
                                   master.get("date") or "", yesterday)
            add = [day for day in days if day not in skip and day not in marked]
            if not add:
                continue
            marked.update(add)
            self.conn.execute(
                "UPDATE events SET done_dates = ?, updated_at = ? WHERE id = ?",
                (",".join(sorted(marked)), now_str(), int(master.get("id") or 0)),
            )
            touched += 1
        if touched:
            self.conn.commit()
        return touched

    def set_done(self, event_id: int, done: bool, day: Optional[str] = None) -> None:
        """标记完成 / 取消完成。

        重复日程按「哪一天」记进 done_dates，母事件不动——否则一次完成会让整串
        （包括以后每一次）都显示成已完成，就是用户反馈的那个问题。
        """
        row = self.get_event(event_id)
        if row is None:
            return
        if not normalize_repeat(row.get("repeat") or ""):
            self.conn.execute(
                "UPDATE events SET done = ?, updated_at = ? WHERE id = ?",
                (1 if done else 0, now_str(), event_id),
            )
            self.conn.commit()
            return
        target = str(day or row.get("date") or "")[:10]
        if not target:
            return
        days = {part.strip() for part in str(row.get("done_dates") or "").split(",")
                if part.strip()}
        if done:
            days.add(target)
        else:
            days.discard(target)
        self.conn.execute(
            "UPDATE events SET done_dates = ?, done = 0, updated_at = ? WHERE id = ?",
            (",".join(sorted(days)), now_str(), int(event_id)),
        )
        self.conn.commit()

    def events_between(self, start: str, end: str) -> List[Dict[str, Any]]:
        """区间里的日程（含**重复日程**展开出来的每一次）。

        重复日程只在库里存一条「母事件」（repeat 非空），这里按规则把落在区间里的
        日期展开成多条，每条带 `repeat_of`（母事件 id），界面照常当普通日程画。
        """
        rows = self.conn.execute(
            "SELECT * FROM events WHERE (repeat IS NULL OR repeat = '')"
            " AND date BETWEEN ? AND ? ORDER BY date, start_time, id",
            (start, end),
        ).fetchall()
        items = [self._event_row(r) for r in rows]
        try:
            masters = self.conn.execute(
                "SELECT * FROM events WHERE repeat IS NOT NULL AND repeat != ''"
                " AND date <= ? ORDER BY date, start_time, id", (end,)).fetchall()
        except Exception:
            masters = []
        for row in masters:
            master = self._event_row(row)
            skip = {part.strip() for part in str(master.get("repeat_skip") or "").split(",")
                    if part.strip()}
            # 「哪几次做完了」按 done_dates 记，所以第一次完成不会把以后每一次都带成完成
            done_days = {part.strip() for part in str(master.get("done_dates") or "").split(",")
                         if part.strip()}
            notified_days = {part.strip()
                             for part in str(master.get("notified_dates") or "").split(",")
                             if part.strip()}
            master_done = bool(master.get("done"))
            master_notified = bool(master.get("notified"))
            first_day = str(master.get("date") or "")[:10]
            until = str(master.get("repeat_until") or "")[:10]
            for day in recurrence_days(master.get("date") or "",
                                       master.get("repeat") or "", start, end):
                if until and day > until:
                    continue
                if day in skip:
                    continue                  # 这一次被单独删掉了
                occurrence = dict(master)
                occurrence["date"] = day
                occurrence["done"] = master_done or day in done_days
                occurrence["notified"] = master_notified or day in notified_days
                if day != first_day:
                    occurrence["repeat_of"] = master.get("id")
                items.append(occurrence)
        items.sort(key=lambda it: (str(it.get("date") or ""),
                                   str(it.get("start_time") or ""),
                                   int(it.get("id") or 0)))
        return items

    def events_on(self, date: str) -> List[Dict[str, Any]]:
        return self.events_between(date, date)

    def event_index(self, start: str, end: str) -> Dict[str, List[Dict[str, Any]]]:
        index: Dict[str, List[Dict[str, Any]]] = {}
        for item in self.events_between(start, end):
            index.setdefault(item["date"], []).append(item)
        return index

    def counts_between(self, start: str, end: str,
                       exclude_group_ids: Optional[List[int]] = None) -> Dict[str, int]:
        """区间内的日程数；可以排除某些分组（比如课程表导入的课）。"""
        excluded = {int(value) for value in (exclude_group_ids or [])}
        total = done = 0
        for item in self.events_between(start, end):
            try:
                group_id = int(item.get("group_id") or 0)
            except (TypeError, ValueError):
                group_id = 0
            if group_id and group_id in excluded:
                continue
            total += 1
            done += 1 if item.get("done") else 0
        return {"total": total, "done": done}

    def task_candidates(self, days_back: int = 30, days_forward: int = 14) -> List[Dict[str, Any]]:
        today = datetime.now().date()
        start = (today - timedelta(days=days_back)).strftime("%Y-%m-%d")
        end = (today + timedelta(days=days_forward)).strftime("%Y-%m-%d")
        return self.events_between(start, end)

    def pending_reminders(self, now: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """到点该弹的提醒（**含重复日程展开出来的那一天**）。

        规则（与 Rust 版逐条对齐）：
        * 只看「补提醒窗口」内到点的：默认 12 小时（设置项 `remind_catchup`），
          所以两个月前的过期日程不会被翻出来；
        * 已经结束超过这个窗口的不提醒，窗口内错过的仍然补一次；
        * 重复日程按天算「提醒过没有」，一次提醒不会把以后每一次都吃掉。
        """
        now = now or datetime.now()
        try:
            hours = int(self.get_setting("remind_catchup", "12") or 12)
        except (TypeError, ValueError):
            hours = 12
        hours = max(0, min(168, hours))
        cutoff = now - timedelta(hours=hours)
        start = (now.date() - timedelta(days=1)).strftime("%Y-%m-%d")
        end = now.strftime("%Y-%m-%d")
        out: List[Dict[str, Any]] = []
        for item in self.events_between(start, end):
            if item.get("done") or item.get("notified"):
                continue
            minutes = item.get("remind_minutes")
            if minutes is None:
                continue
            try:
                day = datetime.strptime(str(item.get("date") or "")[:10], "%Y-%m-%d")
                begin = _to_dt(str(item.get("date") or "")[:10],
                               _clock5(str(item.get("start_time") or "")))
                finish_text = str(item.get("end_time") or "").strip()
                finish = _to_dt(str(item.get("date") or "")[:10],
                                _clock5(finish_text) if finish_text else "23:59")
            except (TypeError, ValueError):
                continue
            if finish < begin:                      # 跨夜
                finish += timedelta(days=1)
            if finish < cutoff or finish < now:
                # 结束太久的、以及已经结束的，都不再补提醒（补提醒只对「正在进行」的有意义）
                continue
            due = begin - timedelta(minutes=int(minutes))
            if str(item.get("repeat") or ""):
                snooze = _parse_dt(item.get("snooze_until"))
                if snooze is not None and snooze.date() == day.date() and snooze > due:
                    due = snooze
            else:
                stored = _parse_dt(item.get("remind_at"))
                if stored is not None:
                    due = stored
            if due > now:
                continue
            item = dict(item)
            item["remind_at"] = due.strftime("%Y-%m-%d %H:%M:%S")
            out.append(item)
        out.sort(key=lambda one: str(one.get("remind_at") or ""))
        return out

    def mark_notified(self, event_id: int, day: Optional[str] = None) -> None:
        """记「这一次提醒过了」。重复日程按天记，不动母行的 notified。"""
        row = self.get_event(event_id)
        if row is None:
            return
        if not normalize_repeat(row.get("repeat") or ""):
            self.conn.execute("UPDATE events SET notified = 1 WHERE id = ?", (event_id,))
            self.conn.commit()
            return
        target = str(day or row.get("date") or "")[:10]
        if not target:
            return
        days = {part.strip() for part in str(row.get("notified_dates") or "").split(",")
                if part.strip()}
        days.add(target)
        self.conn.execute("UPDATE events SET notified_dates = ? WHERE id = ?",
                          (",".join(sorted(days)), int(event_id)))
        self.conn.commit()

    def snooze(self, event_id: int, until: datetime, day: Optional[str] = None) -> None:
        row = self.get_event(event_id)
        if row is None:
            return
        text = until.strftime("%Y-%m-%d %H:%M:%S")
        if not normalize_repeat(row.get("repeat") or ""):
            self.conn.execute(
                "UPDATE events SET notified = 0, remind_at = ? WHERE id = ?",
                (text, event_id),
            )
            self.conn.commit()
            return
        target = str(day or row.get("date") or "")[:10]
        days = {part.strip() for part in str(row.get("notified_dates") or "").split(",")
                if part.strip()}
        days.discard(target)
        self.conn.execute(
            "UPDATE events SET snooze_until = ?, notified_dates = ? WHERE id = ?",
            (text, ",".join(sorted(days)), int(event_id)),
        )
        self.conn.commit()

    def set_series_done(self, event_id: int, done: bool) -> None:
        """整条重复系列一起标完成 / 取消（`done_dates='*'` 是「整串」的标记）。"""
        self.conn.execute(
            "UPDATE events SET done = ?, done_dates = ?, updated_at = ? WHERE id = ?",
            (1 if done else 0, "*" if done else "", now_str(), int(event_id)),
        )
        self.conn.commit()

    # ------------------------------------------------------------------ 邮件
    @staticmethod
    def _mail_row(row: sqlite3.Row) -> Dict[str, Any]:
        item = dict(row)
        try:
            item["tasks"] = json.loads(item.get("tasks_json") or "[]")
        except Exception:
            item["tasks"] = []
        try:
            item["attachments"] = json.loads(item.get("attachments_json") or "[]")
        except Exception:
            item["attachments"] = []
        return item

    def add_mail(
        self,
        to_addr: str,
        subject: str,
        html: str,
        text: str,
        tasks: Iterable[Dict[str, Any]] = (),
        attachments: Iterable[Dict[str, Any]] = (),
        note: str = "",
        status: str = "draft",
        error: str = "",
        sent_at: Optional[str] = None,
    ) -> int:
        cur = self.conn.execute(
            "INSERT INTO mails(to_addr, subject, html, text, tasks_json, attachments_json,"
            " note, status, error, created_at, sent_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (
                to_addr, subject, html, text,
                json.dumps(list(tasks), ensure_ascii=False),
                json.dumps(list(attachments), ensure_ascii=False),
                note, status, error, now_str(), sent_at,
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def update_mail(self, mail_id: int, **fields: Any) -> None:
        allowed = {
            "to_addr", "subject", "html", "text", "tasks_json",
            "attachments_json", "note", "status", "error", "sent_at",
        }
        fields = {k: v for k, v in fields.items() if k in allowed}
        if not fields:
            return
        sets = ", ".join(f"{key} = ?" for key in fields)
        self.conn.execute(f"UPDATE mails SET {sets} WHERE id = ?", [*fields.values(), mail_id])
        self.conn.commit()

    def set_mail_status(self, mail_id: int, status: str, error: str = "") -> None:
        sent_at = now_str() if status == "sent" else None
        self.conn.execute(
            "UPDATE mails SET status = ?, error = ?, sent_at = ? WHERE id = ?",
            (status, error, sent_at, mail_id),
        )
        self.conn.commit()

    def get_mail(self, mail_id: int) -> Optional[Dict[str, Any]]:
        row = self.conn.execute("SELECT * FROM mails WHERE id = ?", (mail_id,)).fetchone()
        return self._mail_row(row) if row else None

    def list_mails(self, query: str = "") -> List[Dict[str, Any]]:
        sql = "SELECT * FROM mails"
        params: List[Any] = []
        if query:
            like = f"%{query}%"
            sql += " WHERE subject LIKE ? OR to_addr LIKE ? OR text LIKE ?"
            params = [like, like, like]
        sql += " ORDER BY COALESCE(sent_at, created_at) DESC, id DESC"
        rows = self.conn.execute(sql, params).fetchall()
        return [self._mail_row(r) for r in rows]

    def mail_counts(self) -> Dict[str, int]:
        rows = self.conn.execute("SELECT status, COUNT(*) AS c FROM mails GROUP BY status").fetchall()
        counts = {"draft": 0, "sent": 0, "failed": 0}
        for row in rows:
            counts[row["status"]] = int(row["c"])
        counts["total"] = sum(counts.values())
        return counts

    def delete_mail(self, mail_id: int) -> None:
        self.conn.execute("DELETE FROM mails WHERE id = ?", (mail_id,))
        self.conn.commit()

    # ------------------------------------------------------------------ 联系人
    def list_contacts(self) -> List[Dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT * FROM contacts ORDER BY id ASC"
        ).fetchall()
        return [dict(r) for r in rows]

    def add_contact(self, name: str, email: str) -> int:
        existing = self.conn.execute(
            "SELECT id FROM contacts WHERE email = ?", (email.strip(),)
        ).fetchone()
        if existing:
            self.conn.execute(
                "UPDATE contacts SET name = ? WHERE id = ?", (name.strip(), existing["id"])
            )
            self.conn.commit()
            return int(existing["id"])
        cur = self.conn.execute(
            "INSERT INTO contacts(name, email, created_at) VALUES (?,?,?)",
            (name.strip(), email.strip(), now_str()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def delete_contact(self, contact_id: int) -> None:
        self.conn.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
        self.conn.commit()


    # ------------------------------------------------------------------ 日程分组
    def list_groups(self) -> List[Dict[str, Any]]:
        rows = self.conn.execute("SELECT * FROM event_groups ORDER BY id").fetchall()
        return [dict(row) for row in rows]

    def group_colors(self) -> Dict[int, str]:
        return {int(row["id"]): str(row["color"]) for row in self.list_groups()}

    def add_group(self, name: str, color: str = "teal") -> int:
        cur = self.conn.execute(
            "INSERT INTO event_groups(name, color, created_at) VALUES (?,?,?)",
            (name.strip() or "新分组", color, now_str()),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def update_group(self, group_id: int, name: str | None = None,
                     color: str | None = None) -> None:
        sets, params = [], []
        if name:
            sets.append("name = ?")
            params.append(name.strip())
        if color:
            sets.append("color = ?")
            params.append(color)
        if not sets:
            return
        params.append(int(group_id))
        self.conn.execute(f"UPDATE event_groups SET {', '.join(sets)} WHERE id = ?", params)
        if color:
            # 改组色时同步组内所有日程，保证「同组同色」
            self.conn.execute(
                "UPDATE events SET color = ?, updated_at = ? WHERE group_id = ?",
                (color, now_str(), int(group_id)),
            )
        self.conn.commit()

    def delete_group(self, group_id: int) -> None:
        self.conn.execute("UPDATE events SET group_id = NULL WHERE group_id = ?",
                          (int(group_id),))
        self.conn.execute("DELETE FROM event_groups WHERE id = ?", (int(group_id),))
        self.conn.commit()
